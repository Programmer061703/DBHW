Creates a MockDatabase that takes in a .CSV file and allows you to manipulate it. 
